<?php
$db['type']="type";
$db['host']="hostname";
$db['user']="dbuser";
$db['pass']="dbpass";
$db['dbname']="ts3_ranksystem";
?>
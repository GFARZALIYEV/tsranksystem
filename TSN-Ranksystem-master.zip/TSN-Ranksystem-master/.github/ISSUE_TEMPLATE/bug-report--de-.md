---
name: Bug report [DE]
about: Melde uns dein Problem, um zur Verbesserung beizutragen.
title: ''
labels: ''
assignees: ''

---

**Ranksystem Version:**

**Beschreibung:**
**1) Was hast du getan?**

**2) Was war deine Erwartung?**

**3) Was ist stattdessen passiert?**

**Ranksystem Log**
_Poste einen Log vom letzten Start des Ranksystems._
_Den Log teilst du am besten z.B. mit https://pastebin.com/ (Das macht es übersichtlicher)._

---
name: Bug report [EN]
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Ranksystem Version:**

**Description:**
**1) What did you do?**

**2) What did you expect?**

**3) What result did you get?**

**Ranksystem Log**
_Add a Ranksystem-Log extract of the last startup._
_You can also use https://pastebin.com/ for this and share us the link._

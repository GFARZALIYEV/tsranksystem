---
name: Feature request [DE]
about: Schlage eine Idee für das Projekt vor
title: ''
labels: Feature request
assignees: ''

---

Unterscheide, ob es sich um ein bestehendes oder ein neues Feature handelt....
 
**Vorhandenes Feature**
 
***1) Ich beziehe mich auf das folgende bestehende Feature:*****
 
***2) Was möchtest du hinzufügen oder ändern?*****
 
***3) Was wäre der Vorteil?*****
_Bitte schlage die Funktion nur vor, wenn du denkst, dass auch andere davon profitieren würden._
 
**Neue Funktion**
 
***1) Was sollte dieses Feature tun?*****
 
***2) Wo soll es sich befinden? *****
_In welchem bestehenden Teil des Ranksystems würdest du diese neue Funktion hinzufügen?_
 
***3) Was wäre der Nutzen?*****
_Bitte schlage die Funktion nur vor, wenn du denkst, dass auch andere davon profitieren würden._

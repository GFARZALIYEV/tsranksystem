---
name: Feature request [EN]
about: Suggest an idea for this project
title: ''
labels: Feature request
assignees: ''

---

Distinguish whether it refers to an existing or new feature..
 
**Existing Feature**
 
***1) I am referring to the following existing feature:***
 
***2) What do you want to add or change on it?***
 
***3) What would be the benefit?***
_Please only report this feature, when you think also other people would have a benefit of it._
 
**New Feature**
 
***1) What should this feature do?***
 
***2) Where should it be located?***
_On which existing part of the Ranksystem you would add this new feature?_
 
***3) What would be the benefit?***
_Please only report this feature, when you think also other people would have a benefit of it._
